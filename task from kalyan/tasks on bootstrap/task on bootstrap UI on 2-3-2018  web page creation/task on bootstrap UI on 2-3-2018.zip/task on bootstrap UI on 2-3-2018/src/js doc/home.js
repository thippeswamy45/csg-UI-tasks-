
$("#message_nav_header1").click(function(){	
	$("#message_nav_modal").modal('hide');	  
	
});
$("#message_inner_modal .close_modal").click('close',function(){
		$("#message_nav_modal").modal('show');
});

$(".popover").popover('show');
	